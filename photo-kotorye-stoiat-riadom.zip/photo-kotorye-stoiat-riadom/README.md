# Photo kotorye stoiat riadom!

A Pen created on CodePen.io. Original URL: [https://codepen.io/Maxim-Sapozhnikov-MaximSap/pen/MWRPNrg](https://codepen.io/Maxim-Sapozhnikov-MaximSap/pen/MWRPNrg).

